import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookCard } from "@/components/book-card"

interface Book {
  id: string
  title: string
  image: string
  link: string
}

const dcgBooks: Book[] = [
  { id: "dcg1", title: "DCG UE1: Fondamentaux du Droit", image: "/image.png", link: "https://example.com/dcg-ue1" },
  { id: "dcg2", title: "DCG UE2: Droit des Sociétés", image: "/image.png", link: "https://example.com/dcg-ue2" },
  { id: "dcg3", title: "DCG UE3: Fiscalité", image: "/image.png", link: "https://example.com/dcg-ue3" },
  { id: "dcg4", title: "DCG UE4: Comptabilité", image: "/image.png", link: "https://example.com/dcg-ue4" },
  { id: "dcg5", title: "DCG UE5: Économie", image: "/image.png", link: "https://example.com/dcg-ue5" },
  { id: "dcg6", title: "DCG UE6: Finance d'Entreprise", image: "/image.png", link: "https://example.com/dcg-ue6" },
  { id: "dcg7", title: "DCG UE7: Management", image: "/image.png", link: "https://example.com/dcg-ue7" },
  { id: "dcg8", title: "DCG UE8: Systèmes d'Information", image: "/image.png", link: "https://example.com/dcg-ue8" },
]

const dscgBooks: Book[] = [
  {
    id: "dscg1",
    title: "DSCG UE1: Gestion Juridique, Fiscale et Sociale",
    image: "/image.png",
    link: "https://example.com/dscg-ue1",
  },
  { id: "dscg2", title: "DSCG UE2: Finance", image: "/image.png", link: "https://example.com/dscg-ue2" },
  {
    id: "dscg3",
    title: "DSCG UE3: Management et Contrôle de Gestion",
    image: "/image.png",
    link: "https://example.com/dscg-ue3",
  },
  { id: "dscg4", title: "DSCG UE4: Comptabilité et Audit", image: "/image.png", link: "https://example.com/dscg-ue4" },
  {
    id: "dscg5",
    title: "DSCG UE5: Management des Systèmes d'Information",
    image: "/image.png",
    link: "https://example.com/dscg-ue5",
  },
  { id: "dscg6", title: "DSCG UE6: Anglais des Affaires", image: "/image.png", link: "https://example.com/dscg-ue6" },
  { id: "dscg7", title: "DSCG UE7: Mémoire Professionnel", image: "/image.png", link: "https://example.com/dscg-ue7" },
]

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gray-800 text-gray-100 flex flex-col items-center py-12 px-4 sm:px-6 lg:px-8">
      <h1 className="text-4xl font-extrabold text-center mb-10 tracking-tight lg:text-5xl text-gray-100">
        Explorez nos Livres DCG & DSCG
      </h1>
      <Tabs defaultValue="dcg" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2 mb-10 bg-gray-700 rounded-lg p-1 shadow-lg mx-auto">
          <TabsTrigger
            value="dcg"
            className="data-[state=active]:bg-gray-600 data-[state=active]:text-gray-100 rounded-md px-4 py-2 text-sm font-medium transition-colors duration-200 hover:bg-gray-600/50"
          >
            DCG
          </TabsTrigger>
          <TabsTrigger
            value="dscg"
            className="data-[state=active]:bg-gray-600 data-[state=active]:text-gray-100 rounded-md px-4 py-2 text-sm font-medium transition-colors duration-200 hover:bg-gray-600/50"
          >
            DSCG
          </TabsTrigger>
        </TabsList>
        <TabsContent value="dcg" className="w-full">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {dcgBooks.map((book) => (
              <BookCard key={book.id} title={book.title} imageSrc={book.image} link={book.link} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="dscg" className="w-full">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {dscgBooks.map((book) => (
              <BookCard key={book.id} title={book.title} imageSrc={book.image} link={book.link} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </main>
  )
}
