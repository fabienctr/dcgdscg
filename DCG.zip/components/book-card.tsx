import Image from "next/image"
import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"

interface BookCardProps {
  title: string
  imageSrc: string
  link: string
}

export function BookCard({ title, imageSrc, link }: BookCardProps) {
  return (
    <Link href={link} target="_blank" rel="noopener noreferrer" className="block">
      <Card className="h-full flex flex-col justify-between rounded-lg shadow-xl hover:shadow-2xl transition-all duration-300 bg-gray-700 border border-gray-600">
        <CardContent className="p-4 flex items-center justify-center flex-grow">
          <Image
            src={imageSrc || "/placeholder.svg"}
            alt={title}
            width={200}
            height={280}
            className="object-contain rounded-md shadow-md"
          />
        </CardContent>
        <CardFooter className="p-4 pt-0 text-center">
          <h3 className="text-base font-semibold leading-snug text-gray-100">{title}</h3>
        </CardFooter>
      </Card>
    </Link>
  )
}
